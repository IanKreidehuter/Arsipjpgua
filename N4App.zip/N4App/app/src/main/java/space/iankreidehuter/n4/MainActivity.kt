package space.iankreidehuter.n4

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import java.io.File
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Learning Archive N4 — the whole web app (HTML/CSS/JS + all JSON data + images) lives in
 * app/src/main/assets and is shown in a WebView, so every screen works offline.
 * Only the Post section talks to the internet (Google Apps Script URL in assets/config.js).
 */
class MainActivity : AppCompatActivity() {

    private lateinit var root: FrameLayout
    private lateinit var web: WebView
    private var tts: TextToSpeech? = null
    private var insetTop = 0
    private var insetBottom = 0

    private val lightBg = Color.parseColor("#E9F1FC")
    private val darkBg = Color.parseColor("#09101F")
    private var pageReady = false
    private var contentChanged = false
    private var pendingApk: File? = null
    private val home = "https://appassets.androidplatform.net/assets/index.html"
    private val askNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* granted or not, nothing else to do */ }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Japanese voice for the 🔊 buttons
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.JAPAN
                tts?.setSpeechRate(0.85f)
            }
        }

        ContentUpdater.resetIfNewApp(this)

        // Serves assets/ (newer downloaded data first) over https://appassets.androidplatform.net/assets/ (a secure origin: fetch() and localStorage work)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", ContentPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(lightBg)
            overScrollMode = View.OVER_SCROLL_NEVER
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }              // no long-press menu (same as the web protection layer)

            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true                 // saved progress, favourites, settings
                allowFileAccess = false
                allowContentAccess = false
                setSupportZoom(false)
                builtInZoomControls = false
                textZoom = 100
                userAgentString = "$userAgentString N4App/1.0"   // the page checks this to skip the service worker
            }

            webChromeClient = WebChromeClient()          // enables confirm() dialogs

            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    loader.shouldInterceptRequest(request.url)

                // links to other sites (Drive images, URLs in posts) open in the phone's browser
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    if (!request.isForMainFrame || request.url.host == "appassets.androidplatform.net") return false
                    try { startActivity(Intent(Intent.ACTION_VIEW, request.url)) } catch (e: Exception) { /* no browser installed */ }
                    return true
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                    super.onPageStarted(view, url, favicon); pushInsets()
                }
                override fun onPageFinished(view: WebView, url: String?) {
                    super.onPageFinished(view, url); pushInsets()
                    pageReady = true
                    if (contentChanged) refreshContent()
                }
                override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
                    recreate(); return true
                }
            }
            addJavascriptInterface(Bridge(), "Android")
        }

        root = FrameLayout(this).apply {
            setBackgroundColor(lightBg)
            addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        setContentView(root)

        // The page draws behind the system bars; the app tells it how tall the bars are (CSS --sat / --sab).
        ViewCompat.setOnApplyWindowInsetsListener(web) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            val keyboard = ime.bottom > bars.bottom
            v.setPadding(0, 0, 0, if (keyboard) ime.bottom else 0)   // keep the search box above the keyboard
            insetTop = bars.top
            insetBottom = if (keyboard) 0 else bars.bottom
            pushInsets()
            insets
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else { isEnabled = false; onBackPressedDispatcher.onBackPressed() }
            }
        })

        // new-post notifications: ask once (Android 13+), then check the feed about every 30 minutes
        ensurePostChannel(this)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        // instant push: every install listens to the topic "posts" (only when app/google-services.json exists)
        if (FirebaseApp.getApps(this).isNotEmpty()) FirebaseMessaging.getInstance().subscribeToTopic("posts")
        // fallback check every ~30 minutes in case a push is missed
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "post-check", ExistingPeriodicWorkPolicy.KEEP,
            PeriodicWorkRequestBuilder<PostCheckWorker>(30, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
        )

        web.loadUrl(if (intent?.getBooleanExtra("open_post", false) == true) "$home#/post" else home)
        checkAppUpdate()
    }

    private fun indo() = Locale.getDefault().language in listOf("in", "id")

    override fun onResume() {
        super.onResume()
        checkContent()
        pendingApk?.let { if (packageManager.canRequestPackageInstalls()) { pendingApk = null; installApk(it) } }
    }

    /** Downloads newer Kotoba / Kanji / Grammar data (at most every 30 minutes) and refreshes the page when something changed. */
    private fun checkContent() {
        val prefs = getSharedPreferences("n4_content", MODE_PRIVATE)
        if (System.currentTimeMillis() - prefs.getLong("last_check", 0) < 30 * 60_000L) return
        val base = AppConfig.get(this, "N4_UPDATE_BASE")
        if (base.isBlank()) return
        prefs.edit().putLong("last_check", System.currentTimeMillis()).apply()
        Thread {
            if (ContentUpdater.update(this, base)) runOnUiThread { contentChanged = true; if (pageReady) refreshContent() }
        }.start()
    }

    private fun refreshContent() {
        contentChanged = false
        web.postDelayed({
            web.evaluateJavascript("window.N4_refresh && N4_refresh()", null)
            Toast.makeText(this, if (indo()) "Konten diperbarui" else "Content updated", Toast.LENGTH_SHORT).show()
        }, 1500)
    }

    /** Looks for apkupdate/version.json; if it names a newer versionCode, offers Update / Later / Skip. */
    private fun checkAppUpdate() {
        val base = AppConfig.get(this, "N4_UPDATE_BASE")
        if (base.isBlank()) return
        Thread {
            val info = AppUpdater.fetch(base, indo()) ?: return@Thread
            val skipped = getSharedPreferences("n4_content", MODE_PRIVATE).getLong("skip_version", -1)
            if (info.code > AppUpdater.currentVersionCode(this) && info.code != skipped) {
                runOnUiThread { web.postDelayed({ if (!isFinishing) promptUpdate(info) }, 5500) }   // after the 5 s splash
            }
        }.start()
    }

    private fun promptUpdate(info: UpdateInfo) {
        val id = indo()
        AlertDialog.Builder(this)
            .setTitle(if (id) "Pembaruan tersedia" else "Update available")
            .setMessage((if (id) "Versi ${info.name} siap dipasang.\n\n" else "Version ${info.name} is ready.\n\n") + info.notes)
            .setPositiveButton(if (id) "Perbarui" else "Update") { _, _ -> startDownload(info) }
            .setNegativeButton(if (id) "Nanti" else "Later", null)
            .setNeutralButton(if (id) "Abaikan versi ini" else "Skip this version") { _, _ ->
                getSharedPreferences("n4_content", MODE_PRIVATE).edit().putLong("skip_version", info.code).apply()
            }
            .show()
    }

    private fun startDownload(info: UpdateInfo) {
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val box = LinearLayout(this).apply {
            setPadding(48, 32, 48, 8)
            addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle(if (indo()) "Mengunduh pembaruan…" else "Downloading update…")
            .setView(box).setCancelable(false).create()
        dlg.show()
        Thread {
            val f = AppUpdater.download(this, info) { p -> runOnUiThread { bar.progress = p } }
            runOnUiThread {
                dlg.dismiss()
                if (f == null) Toast.makeText(this, if (indo()) "Unduhan gagal. Coba lagi nanti." else "Download failed. Try again later.", Toast.LENGTH_LONG).show()
                else installApk(f)
            }
        }.start()
    }

    private fun installApk(apk: File) {
        if (!packageManager.canRequestPackageInstalls()) {          // the user must allow "install unknown apps" for this app once
            pendingApk = apk
            Toast.makeText(this, if (indo()) "Izinkan aplikasi ini memasang aplikasi, lalu kembali." else "Allow this app to install apps, then come back.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", apk)
        startActivity(Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }

    // tapping a notification while the app is already open jumps to the Post section
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.getBooleanExtra("open_post", false)) web.evaluateJavascript("location.hash='#/post'", null)
    }

    private fun pushInsets() {
        if (!::web.isInitialized) return
        val d = resources.displayMetrics.density
        web.evaluateJavascript(
            "document.documentElement.style.setProperty('--sat','${insetTop / d}px');" +
            "document.documentElement.style.setProperty('--sab','${insetBottom / d}px')", null
        )
    }

    /** Functions the web page can call as window.Android.* */
    inner class Bridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread { tts?.speak(text.take(300), TextToSpeech.QUEUE_FLUSH, null, "n4") }
        }

        /** The Post screen reports the newest post it showed, so that one never triggers a notification. */
        @JavascriptInterface
        fun seenPost(id: String) {
            getSharedPreferences("n4", MODE_PRIVATE).edit().putString("last_post", id).apply()
        }

        @JavascriptInterface
        fun setDark(dark: Boolean) {
            runOnUiThread {
                val c = if (dark) darkBg else lightBg
                root.setBackgroundColor(c)
                web.setBackgroundColor(c)
                val ctl = WindowCompat.getInsetsController(window, root)
                ctl.isAppearanceLightStatusBars = !dark          // dark icons on the light theme
                ctl.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }
}
