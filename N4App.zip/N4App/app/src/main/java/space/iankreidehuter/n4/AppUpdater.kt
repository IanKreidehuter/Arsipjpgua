package space.iankreidehuter.n4

import android.content.Context
import androidx.core.content.pm.PackageInfoCompat
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

data class UpdateInfo(val code: Long, val name: String, val notes: String, val apkUrl: String, val sha256: String?)

/** Looks for <base>/apkupdate/version.json and downloads <base>/apkupdate/<apk> (default ygbaru.apk). */
object AppUpdater {

    fun currentVersionCode(ctx: Context): Long =
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))

    fun fetch(base: String, indonesian: Boolean): UpdateInfo? = try {
        val c = (URL("$base/apkupdate/version.json").openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000; readTimeout = 10000; useCaches = false
        }
        if (c.responseCode != 200) null else {
            val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
            val notes = j.optString(if (indonesian) "notes_id" else "notes_en").ifBlank { j.optString("notes") }
            UpdateInfo(
                j.getLong("versionCode"), j.optString("versionName"), notes,
                "$base/apkupdate/" + j.optString("apk", "ygbaru.apk"),
                j.optString("sha256").ifBlank { null }?.lowercase()
            )
        }
    } catch (e: Exception) { null }

    /** Downloads into cache/apk/update.apk. Returns null if it fails or the SHA-256 does not match. */
    fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File? = try {
        val dir = File(ctx.cacheDir, "apk").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "update.apk")
        val c = (URL(info.apkUrl).openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 30000; useCaches = false }
        if (c.responseCode != 200) null else {
            val total = c.contentLength.toLong()
            val md = MessageDigest.getInstance("SHA-256")
            var done = 0L
            c.inputStream.use { input ->
                out.outputStream().use { o ->
                    val buf = ByteArray(32 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        o.write(buf, 0, n); md.update(buf, 0, n); done += n
                        if (total > 0) onProgress((done * 100 / total).toInt())
                    }
                }
            }
            val sum = md.digest().joinToString("") { "%02x".format(it) }
            if (info.sha256 != null && info.sha256 != sum) { out.delete(); null } else out
        }
    } catch (e: Exception) { null }
}
