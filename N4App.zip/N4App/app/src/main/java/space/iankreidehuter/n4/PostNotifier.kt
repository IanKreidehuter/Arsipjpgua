package space.iankreidehuter.n4

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

const val CHANNEL_POSTS = "posts"

fun ensurePostChannel(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 26) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val title = if (Locale.getDefault().language in listOf("in", "id")) "Postingan baru" else "New posts"
        nm.createNotificationChannel(NotificationChannel(CHANNEL_POSTS, title, NotificationManager.IMPORTANCE_DEFAULT))
    }
}

/**
 * Runs about every 30 minutes (Android decides the exact time) while the phone is online.
 * Asks the Post feed for the newest posts and shows a notification if there is one the user has not seen.
 * It reads the same Apps Script URL as the Post section (assets/config.js), so no extra setup is needed.
 */
class PostCheckWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val cfg = applicationContext.assets.open("config.js").bufferedReader().use { it.readText() }
            val api = Regex("N4_API\\s*=\\s*\"([^\"]*)\"").find(cfg)?.groupValues?.get(1).orEmpty()
            if (api.isBlank()) return@withContext Result.success()

            val conn = (URL("$api?action=list&limit=5&offset=0").openConnection() as HttpURLConnection).apply {
                connectTimeout = 15000; readTimeout = 15000; instanceFollowRedirects = true
            }
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val posts = JSONObject(body).optJSONArray("posts")
            if (posts == null || posts.length() == 0) return@withContext Result.success()

            val prefs = applicationContext.getSharedPreferences("n4", Context.MODE_PRIVATE)
            val last = prefs.getString("last_post", null)
            val newest = posts.getJSONObject(0)
            val newestId = newest.getString("id")

            if (last == null) {                              // first run: remember the feed, do not notify about old posts
                prefs.edit().putString("last_post", newestId).apply()
                return@withContext Result.success()
            }
            if (last == newestId) return@withContext Result.success()

            var fresh = 0
            for (i in 0 until posts.length()) { if (posts.getJSONObject(i).getString("id") == last) break; fresh++ }
            showPostNotification(applicationContext, fresh, newest.optString("username", "Admin"), newest.optString("caption", ""))
            prefs.edit().putString("last_post", newestId).apply()
            Result.success()
        } catch (e: Exception) {
            Result.retry()                                   // offline or the script is busy: try again later
        }
    }
}

/** Shows the "new post" notification. Used by the Firebase push and by the 30-minute fallback check. */
@SuppressLint("MissingPermission")
fun showPostNotification(ctx: Context, count: Int, user: String, caption: String) {
    if (Build.VERSION.SDK_INT >= 33 &&
        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
    ensurePostChannel(ctx)
    val id = Locale.getDefault().language in listOf("in", "id")
    val title = if (count > 1) (if (id) "$count postingan baru" else "$count new posts")
                else (if (id) "Postingan baru dari $user" else "New post from $user")
    val text = caption.ifBlank { if (id) "Ketuk untuk melihat" else "Tap to view" }.take(120)
    val open = PendingIntent.getActivity(
        ctx, 0,
        Intent(ctx, MainActivity::class.java).apply {
            putExtra("open_post", true)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        },
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
    val n = NotificationCompat.Builder(ctx, CHANNEL_POSTS)
        .setSmallIcon(R.drawable.ic_stat_post)
        .setContentTitle(title)
        .setContentText(text)
        .setStyle(NotificationCompat.BigTextStyle().bigText(text))
        .setContentIntent(open)
        .setAutoCancel(true)
        .build()
    NotificationManagerCompat.from(ctx).notify(1001, n)
}
