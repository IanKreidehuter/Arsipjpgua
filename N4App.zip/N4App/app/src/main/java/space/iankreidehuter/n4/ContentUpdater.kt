package space.iankreidehuter.n4

import android.content.Context
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Reads a value from assets/config.js, e.g. N4_UPDATE_BASE. */
object AppConfig {
    fun get(ctx: Context, key: String): String = try {
        val text = ctx.assets.open("config.js").bufferedReader().use { it.readText() }
        Regex(key + "\\s*=\\s*\"([^\"]*)\"").find(text)?.groupValues?.get(1).orEmpty().trimEnd('/')
    } catch (e: Exception) { "" }
}

/**
 * Keeps the Kotoba / Kanji / Grammar JSON files fresh.
 * Newer copies are downloaded from the website into the app's private storage; the page then reads them
 * instead of the files bundled in the APK. Offline, the last downloaded copy (or the bundled one) is used.
 */
object ContentUpdater {
    /** file name -> JSON key that must hold a non-empty list (a broken upload is rejected, the old copy stays) */
    val FILES = mapOf(
        "ALL_KOSAKATA_N4_FORMS.json" to "kosakata",
        "kanji_lessonfileN4.json" to "lessons",
        "kotoba_lesson_26-35.json" to "lessons",
        "ALL_GRAMMAR_N4.json" to "pelajaran"
    )

    fun dir(ctx: Context): File = File(ctx.filesDir, "content").apply { mkdirs() }

    /** After the app itself is updated, drop old downloads so the newer bundled data is not hidden by stale copies. */
    fun resetIfNewApp(ctx: Context) {
        val prefs = ctx.getSharedPreferences("n4_content", Context.MODE_PRIVATE)
        val code = AppUpdater.currentVersionCode(ctx)
        if (prefs.getLong("app_code", -1) != code) {
            dir(ctx).listFiles()?.forEach { it.delete() }
            prefs.edit().clear().putLong("app_code", code).apply()
        }
    }

    /** Returns true if at least one file was replaced. Uses ETag / Last-Modified so unchanged files are not downloaded again. */
    fun update(ctx: Context, base: String): Boolean {
        val prefs = ctx.getSharedPreferences("n4_content", Context.MODE_PRIVATE)
        var changed = false
        for ((name, key) in FILES) {
            try {
                val c = (URL("$base/$name").openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000; readTimeout = 20000; useCaches = false
                    prefs.getString("etag_$name", null)?.let { setRequestProperty("If-None-Match", it) }
                    prefs.getString("lm_$name", null)?.let { setRequestProperty("If-Modified-Since", it) }
                }
                if (c.responseCode != 200) continue                        // 304 = unchanged, anything else = keep what we have
                val text = c.inputStream.bufferedReader().use { it.readText() }
                val list = JSONObject(text).optJSONArray(key)
                if (list == null || list.length() == 0) continue           // not valid data: ignore
                val tmp = File(dir(ctx), "$name.tmp")
                tmp.writeText(text)
                val target = File(dir(ctx), name)
                if (!tmp.renameTo(target)) { target.writeText(text); tmp.delete() }
                prefs.edit()
                    .putString("etag_$name", c.getHeaderField("ETag"))
                    .putString("lm_$name", c.getHeaderField("Last-Modified"))
                    .apply()
                changed = true
            } catch (e: Exception) { /* offline or bad response: try again next time */ }
        }
        return changed
    }
}

/** Serves downloaded data files first and falls back to the copies bundled in assets/. */
class ContentPathHandler(private val ctx: Context) : WebViewAssetLoader.PathHandler {
    private val assets = WebViewAssetLoader.AssetsPathHandler(ctx)
    override fun handle(path: String): WebResourceResponse? {
        if (path in ContentUpdater.FILES) {
            val f = File(ContentUpdater.dir(ctx), path)
            if (f.isFile) {
                return WebResourceResponse("application/json", "utf-8", f.inputStream()).apply {
                    responseHeaders = mapOf("Cache-Control" to "no-cache")
                }
            }
        }
        return assets.handle(path)
    }
}
