package space.iankreidehuter.n4

import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

/** Receives the instant "new post" message that the Apps Script sends to the topic "posts". */
class PostMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(message: RemoteMessage) {
        val data = message.data
        val id = data["id"] ?: return
        val prefs = getSharedPreferences("n4", MODE_PRIVATE)
        if (prefs.getString("last_post", null) == id) return          // already notified or already seen in the app
        showPostNotification(applicationContext, 1, data["username"] ?: "Admin", data["caption"] ?: "")
        prefs.edit().putString("last_post", id).apply()
    }

    override fun onNewToken(token: String) {
        try { FirebaseMessaging.getInstance().subscribeToTopic("posts") } catch (e: Exception) { /* Firebase not set up */ }
    }
}
